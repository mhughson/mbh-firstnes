# Instructions

## Files and folders
Add the folder **ninjapad/** to your project root  
Add the file **ninjapad-config.js** to your project root  

## HTML
Copy-paste the content of **ninjapad.html** into the end of your **\<body\>** metatag  

## Config
Edit the file **ninjapad-config.js** to your liking  
