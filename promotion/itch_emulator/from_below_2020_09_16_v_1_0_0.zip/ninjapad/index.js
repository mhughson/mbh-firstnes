const ninjapad = {};
