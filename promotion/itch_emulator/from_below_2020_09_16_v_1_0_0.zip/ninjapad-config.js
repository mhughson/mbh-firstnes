const DEBUG = true;
const DEADZONE = 2; //vw
const DISPLAY = "emu-canvas";
const SCREEN = "emu-screen";
const EMULATOR = "jsnes";
const SINGLE_ROM = true;
const DEFAULT_ROM = "roms/from_below_2020_09_16_v_1_0_0.nes";
const HOMEPAGE = "https://twitter.com/matthughson";
const ABOUT = `
Follow me on Twitter:<br/>
<a href="${HOMEPAGE}" target="_blank">
<font color="yellow">Matt Hughson</font>
</a>
`
